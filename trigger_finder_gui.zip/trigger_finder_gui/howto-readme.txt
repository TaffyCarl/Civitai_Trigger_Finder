Version 2:
Tidier, as in the headings are now centred in the html file, the thumbnails are downloaded to your machine, therefore you aren't going to lose thumbnails if the LoRA maker deletes it from Civitai and as for the mp4 issue, that's been resolved by downloading a copy to your machine also.
Just double click on the exe file and select the required folders (input and output) then sit back and wait - it'll tell you when it's finished.
Cheers
Taff
16/8/25
