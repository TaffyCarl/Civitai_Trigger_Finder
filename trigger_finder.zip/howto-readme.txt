How to run, install etc.

RECOMMENDATION for Pinokio Users: Install Python x64 bit from here - https://www.python.org/downloads/windows, click on Download Windows installer (64-bit), save it then install it. 
Make sure to tick the check boxes for idle, add to path etc etc this will make running apps outside of Pinokio a lot simpler.
Next head to the Pure Fooocus AI Facebook page and under FILES you will see trigger.zip - download that. Once you've got it, unpack it using something like 7Zip and navigate to the trigger_finder.py file, RIGHT click on it, select Edit with IDLE or edit it with the notepad, and look for the input/output folders you WILL need to change to suit your machine, see below and save it.
If you've decided to install Python as recommended just double click on it and it will begin doing what you wanted it to do. If you've decided NOT to install Python and just rely on the Pinokio install, just open a command prompt, Windows Search type cmd and press enter navigate to where you saved the file example c:\users\name\desktop\trigger and type in the following 'python trigger_finder.py' (no quotes) so it looks like this c:\users\name\desktop\trigger\python trigger_finder.py and press enter on your keyboard.

What to edit:
Look for this section in the py file and edit it to suit your machine, if you don't it won't work!
def main():
    # Specify the folder to scan and output folder (modify these paths as needed)

    folder_path = r"C:\Users\AI\models\loras"
    
    output_folder = r"C:\Users\AI\lora_triggers"

EDIT: Version 2 is tidier, as in the headings are now centred in the html file.