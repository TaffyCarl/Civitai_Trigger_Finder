READ ME!

Before going on with all the gibberish, Civitai LoRA Trigger Finder up to and including V5 (this version) is copyright Carl Bratcher aka Taffy_Carl, you are free to use it but not reverse engineer, modify, whatever it. While it's a free program, a donation of Buzz on Civitai would be nice ;-) If you see this in places other than Civitai, Github and Pure Fooocus AI on Facebook please let me know. Finally, NEVER PAY FOR IT, It's free apart from a Buzz donation grovel grovel :-)

Installation is simple, create a folder called Lora Triggers to wherever you want the output files to go, I'd recommend inside the root of your AI Image program but it's up to you. Extract the zip file (leave it intact in its own folder) to there or wherever you want to put it on your PC. When it's extracted, Open it (obviously) and copy the  image1.png and image2.png to the Lora Triggers folder you created, I did have it automatically do it BUT system security is different on everyones PC's so this was the more convenient way of doing it and avoiding Windows having a rat attack. Hold your right mouse button down on the Lora_Trigger_Finder_V5.exe and select 'Send To' then from the popout select Desktop (Create shortcut) and a shortcut is now on your desktop. This isn't a necessity but it may make it easier for those who aren't really computer savvy.

The CivitAI LoRA Trigger Finder has been updated to Version 5, now only available as an Windows executable as there was an un-noticed bug in V3, it didn't append the missing LoRA's to the lora_not_found.txt file, all it did was add them again when it was re-run, that's now been fixed. You can also change the output colour of the HTML file 'Dark, Light or System' - just remember that once you've set it, that's the colour the html output will always be unless you delete the html and start from scratch. You now have the option to view the HTML,the TXT version, the JSON and the Not Found LoRA's text directly from the GUI.

The files it creates are:
lora_not_found_DD-MM-YYYY_{time}.txt - self explanatory
lora_triggers_DD-MM-YYYY_{time}.html - a pretty html with a search box, a copy triggers button and thumbnails
lora_triggers_DD-MM-YYYY_{time}.json (don't manually edit this if you don't know what you're doing!) Please see editing_json.txt in this folder
lora_triggers_DD-MM-YYYY_{time}.txt - added if you prefer to read a text file
config.json - An automatic field filler for the LoRA directory and the Output directory to save you having to do it every time you run it.
lora_trigger_finder.txt - a debug file that I decided to leave as it helps if it goes belly up but I can't see that happening, but who knows.

If you happen to remove any LoRA's you will have to delete the above output files and re-run it so it can re-populate the output files.

Cheers
Taff
19/08/25 